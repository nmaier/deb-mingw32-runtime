#include <stdlib.h>
void _Exit(int status)
	{  _exit(status); }
