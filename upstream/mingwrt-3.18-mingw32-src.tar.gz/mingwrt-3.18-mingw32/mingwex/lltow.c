#include <stdlib.h>
wchar_t* lltow(long long _n, wchar_t * _w, int _i)
	{ return _i64tow (_n, _w, _i); } 
