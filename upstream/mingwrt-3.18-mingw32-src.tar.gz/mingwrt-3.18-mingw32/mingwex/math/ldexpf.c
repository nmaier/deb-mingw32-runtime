#include <math.h>
float ldexpf (float x, int expn)
  {return (float) ldexp (x, expn);}
