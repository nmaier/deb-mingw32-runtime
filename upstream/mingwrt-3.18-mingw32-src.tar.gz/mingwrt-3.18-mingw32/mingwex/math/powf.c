#include <math.h>
float powf (float x, float y)
  {return (float) pow (x, y);}
