#include <math.h>
float sinhf (float x)
  {return (float) sinh (x);}
