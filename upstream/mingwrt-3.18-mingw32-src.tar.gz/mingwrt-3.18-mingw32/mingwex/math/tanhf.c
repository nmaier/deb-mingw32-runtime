#include <math.h>
float tanhf (float x)
  {return (float) tanh (x);}
