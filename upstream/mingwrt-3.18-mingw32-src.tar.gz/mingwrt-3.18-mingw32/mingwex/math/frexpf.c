#include <math.h>
float frexpf (float x, int* expn)
  {return (float)frexp(x, expn);}
