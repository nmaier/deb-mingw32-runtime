#include <stdlib.h>
long long atoll (const char * _c)
	{ return _atoi64 (_c); }
