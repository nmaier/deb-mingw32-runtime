#include	<wchar.h>
#include	<stdio.h>

int
fwide(FILE* stream, int mode)
{
  return mode; /* Nothing to do.  */
}

