/*  Define here in .bss in case not defined by linker script. */
char __RUNTIME_PSEUDO_RELOC_LIST_END__ = 0;
char __RUNTIME_PSEUDO_RELOC_LIST__ = 0;
