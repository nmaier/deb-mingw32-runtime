#include <fcntl.h>

/* Set default file mode to binary */

int _fmode = _O_BINARY; 
